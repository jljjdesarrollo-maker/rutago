'use client';

import { useState, useEffect } from 'react';
import { ArrowLeft, Download, FileText, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { type SavedRecord } from './types';

interface ReportsScreenProps {
  onBack: () => void;
}

export function ReportsScreen({ onBack }: ReportsScreenProps) {
  const [from, setFrom] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() - 1);
    return d.toISOString().split('T')[0];
  });
  const [to, setTo] = useState(() => new Date().toISOString().split('T')[0]);
  const [records, setRecords] = useState<SavedRecord[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchRecords = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/records?from=${from}&to=${to}`);
      const data = await res.json();
      setRecords(data);
    } catch {
      console.error('Error fetching report data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchRecords(); }, [from, to]);

  const totals = records.reduce(
    (acc, r) => ({
      production: acc.production + r.production,
      cajaComun: acc.cajaComun + r.cajaComun,
      totalGastos: acc.totalGastos + r.totalGastos,
      tickets: acc.tickets + r.tickets,
      entregaAyudante: acc.entregaAyudante + r.entregaAyudante,
      entregaCompania: acc.entregaCompania + r.entregaCompania,
    }),
    { production: 0, cajaComun: 0, totalGastos: 0, tickets: 0, entregaAyudante: 0, entregaCompania: 0 }
  );

  const exportCSV = () => {
    const headers = ['Fecha', 'Conductor', 'Ayudante', 'KM', 'Producción', 'Caja Común', 'Total Gastos', 'Tickets', 'Entrega Ayudante', 'Entrega Compañía', 'Frecuencias'];
    const rows = records.map(r => [
      r.date, r.conductor || '', r.ayudanteNombre || '', r.km || '',
      r.production.toFixed(2), r.cajaComun.toFixed(2), r.totalGastos.toFixed(2),
      r.tickets.toFixed(2), r.entregaAyudante.toFixed(2), r.entregaCompania.toFixed(2),
      r.trips.length.toString(),
    ]);
    const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte_${from}_${to}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const formatDate = (dateStr: string) => {
    const [y, m, d] = dateStr.split('-');
    return `${d}/${m}/${y}`;
  };

  return (
    <div className="flex flex-col min-h-[100dvh] bg-gray-50">
      <header className="sticky top-0 z-10 bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={onBack} className="rounded-xl">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-lg font-semibold text-gray-900">Reportes</h1>
      </header>

      <main className="flex-1 overflow-y-auto pb-6">
        <div className="px-4 py-4 space-y-4">
          {/* Date range */}
          <Card className="rounded-2xl border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-gray-500">Desde</Label>
                  <Input type="date" value={from} onChange={e => setFrom(e.target.value)} className="rounded-xl h-11" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-gray-500">Hasta</Label>
                  <Input type="date" value={to} onChange={e => setTo(e.target.value)} className="rounded-xl h-11" />
                </div>
              </div>
            </CardContent>
          </Card>

          {loading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
            </div>
          ) : records.length === 0 ? (
            <div className="text-center py-10 text-gray-400">
              <FileText className="w-10 h-10 mx-auto mb-2" />
              <p>Sin registros en este rango</p>
            </div>
          ) : (
            <>
              {/* Summary totals */}
              <Card className="rounded-2xl border-0 shadow-sm bg-gray-900 text-white">
                <CardContent className="p-4 space-y-2">
                  <p className="text-xs font-bold uppercase tracking-wider text-gray-400">
                    Resumen ({records.length} días)
                  </p>
                  <div className="flex justify-between text-sm"><span className="text-gray-400">Producción Total</span><span className="font-semibold">S/ {totals.production.toFixed(2)}</span></div>
                  <div className="flex justify-between text-sm"><span className="text-gray-400">Caja Común Total</span><span className="font-semibold">S/ {totals.cajaComun.toFixed(2)}</span></div>
                  <div className="flex justify-between text-sm"><span className="text-gray-400">Gastos Totales</span><span className="font-semibold text-red-400">S/ {totals.totalGastos.toFixed(2)}</span></div>
                  <div className="flex justify-between text-sm"><span className="text-gray-400">Entrega Ayudante</span><span className="font-bold text-emerald-400">S/ {totals.entregaAyudante.toFixed(2)}</span></div>
                  <div className="flex justify-between text-sm"><span className="text-gray-400">Entrega Compañía</span><span className="font-bold text-emerald-400">S/ {totals.entregaCompania.toFixed(2)}</span></div>
                </CardContent>
              </Card>

              {/* Export */}
              <Button onClick={exportCSV} variant="outline" className="w-full h-12 rounded-2xl border-2 border-gray-200">
                <Download className="w-5 h-5 mr-2" /> Exportar CSV (Excel)
              </Button>

              {/* Records list */}
              <Card className="rounded-2xl border-0 shadow-sm">
                <CardHeader className="pb-2 pt-4 px-4">
                  <CardTitle className="text-base font-semibold">Detalle por Día</CardTitle>
                </CardHeader>
                <CardContent className="px-4 pb-4 space-y-2">
                  {records.map(r => (
                    <div key={r.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                      <div>
                        <p className="text-sm font-medium">{formatDate(r.date)}</p>
                        <p className="text-xs text-gray-400">{r.trips.length} frec. • {r.conductor || '-'}</p>
                      </div>
                      <div className="text-right text-xs">
                        <p className="text-emerald-600 font-medium">S/ {r.production.toFixed(2)}</p>
                        <p className="text-red-500">-S/ {r.totalGastos.toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
