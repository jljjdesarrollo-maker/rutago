'use client';

import { FileText, BarChart3, Plus, Truck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface HomeScreenProps {
  onGoToForm: () => void;
  onGoToHistory: () => void;
  onGoToReports: () => void;
  recordCount: number;
}

export function HomeScreen({ onGoToForm, onGoToHistory, onGoToReports, recordCount }: HomeScreenProps) {
  return (
    <div className="flex flex-col min-h-[100dvh] bg-gradient-to-b from-emerald-50 to-white">
      <header className="pt-12 pb-6 px-6 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-emerald-600 mb-4">
          <Truck className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900">Control de Transporte</h1>
        <p className="text-gray-500 mt-1 text-sm">Liquidación diaria de transporte público</p>
      </header>

      <main className="flex-1 px-5 pb-6 flex flex-col gap-4">
        <Button
          onClick={onGoToForm}
          className="w-full h-20 text-lg font-semibold rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-200 active:scale-[0.98] transition-transform"
        >
          <Plus className="w-6 h-6 mr-3" />
          Nuevo Registro del Día
        </Button>

        <div className="grid grid-cols-2 gap-3 mt-2">
          <Card
            onClick={onGoToHistory}
            className="cursor-pointer hover:shadow-md transition-shadow rounded-2xl border-0 bg-white shadow-sm"
          >
            <CardContent className="flex flex-col items-center p-4 gap-2">
              <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center">
                <FileText className="w-5 h-5 text-amber-600" />
              </div>
              <p className="font-semibold text-gray-900 text-sm">Historial</p>
              <span className="text-xl font-bold text-emerald-600">{recordCount}</span>
            </CardContent>
          </Card>

          <Card
            onClick={onGoToReports}
            className="cursor-pointer hover:shadow-md transition-shadow rounded-2xl border-0 bg-white shadow-sm"
          >
            <CardContent className="flex flex-col items-center p-4 gap-2">
              <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-blue-600" />
              </div>
              <p className="font-semibold text-gray-900 text-sm">Reportes</p>
              <span className="text-xs text-gray-400">XLS / PDF</span>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="py-4 text-center text-xs text-gray-400">
        Transporte Control v2.0
      </footer>
    </div>
  );
}
